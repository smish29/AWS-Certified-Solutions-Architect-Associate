what is AWS?
well aws is a company which is the leading market share holder of cloud computing.
